# RoomSQL
Demo pour l'utilisation de SQLite avec Room pour Android

Correspond aux tutoriels video sur youtube correspondants:
Mise en place : 
https://www.youtube.com/watch?v=XMN3y8d2Dr0 
https://github.com/jorisdeguet/RoomSQL/

Débogage : 
https://www.youtube.com/watch?v=t8O7EN61egA 
https://github.com/jorisdeguet/RoomSQL/tree/RoomDebug

Transaction : 
https://www.youtube.com/watch?v=SB58qEx9XBU
https://github.com/jorisdeguet/RoomSQL/tree/RoomTransaction

Performance (index et batch) : 
https://www.youtube.com/watch?v=fpdADjOecTw
https://github.com/jorisdeguet/RoomSQL/tree/RoomPerformance

Appels asynchrones : 
https://www.youtube.com/watch?v=T-iZudCh2xo
https://github.com/jorisdeguet/RoomSQL/tree/RoomRxJava
